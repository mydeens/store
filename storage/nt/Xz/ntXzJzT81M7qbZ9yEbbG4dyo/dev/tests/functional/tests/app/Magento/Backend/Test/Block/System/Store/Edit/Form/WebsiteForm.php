<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Backend\Test\Block\System\Store\Edit\Form;

use Magento\Mtf\Block\Form;

/**
 * Class WebsiteForm
 * Form for Website creation
 */
class WebsiteForm extends Form
{
    //
}
